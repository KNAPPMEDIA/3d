FIGHTERO MMA Short Variant2, version V05
Delivery for the KitBuilder 3D configurator
Knapp Media, 27.11.2026
New UV layout: the UV template is now the real Fightero production cut pattern of this short (pattern sheet group 5, "M 1").
A design made on the production cut pieces lands on the 3D model inside the sew lines. Geometry, topology, normals and zones
are exactly V04, only the UVs changed (plus 8 vertices split for one new UV seam, see TECHNICAL).

WHAT CHANGED SINCE V04 (KitBuilder feedback "the cut templates do not fit the 3D model")
- V04 used our own flattening of the 3D parts. V05 uses the production pattern: every 3D part that has a production piece
  has the outline of that piece's SEW line (cut line inset by the seam allowance), all pieces share one scale,
  stand upright like on the pattern sheet, are not mirrored (outside face up) and sit in the same arrangement as on the sheet.
- The template shows the production cut line (black, outer line = seam allowance) and the sew line (red, = edge of the 3D part).
- Parts of the 3D model that have no production piece (inside, hidden or construction parts) are packed below, same scale.

FILES
FIGHTERO_Shorts_Variant2_V05.glb                    main file, 166,878 triangles, 3.9 MB
FIGHTERO_Shorts_Variant2_V05_Draco.glb              same geometry, Draco compressed (520 KB, for the web)
FIGHTERO_Shorts_Variant2_V05.gltf                   same file as glTF (buffer embedded)
UV_Map/FIGHTERO_Shorts_Variant2_V05_UV_Map.ai           Illustrator template, vector (PDF compatible .ai)
UV_Map/FIGHTERO_Shorts_Variant2_V05_UV_Map.pdf          same template as PDF, vector
UV_Map/FIGHTERO_Shorts_Variant2_V05_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill,
                               Not on model (hatched), Grid orientation 10 cm, Cut lines, Sew lines, Island splits,
                               Island outlines (closed, for clipping masks), Labels; cut and sew lines are closed paths
UV_Map/FIGHTERO_Shorts_Variant2_V05_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_Shorts_Variant2_V05_UV_Map_Preview.png  preview 1600 px
Images/FIGHTERO_Shorts_Variant2_V05_Zones_Overview.png  front, back and side with every zone coloured and labelled, legend with the material names
Images/FIGHTERO_Shorts_Variant2_V05_Preview_White.png   the model in white: front, side, back, three quarter (geometry unchanged since V04)
validator_FIGHTERO_Shorts_Variant2_V05.txt          Khronos glTF Validator output for every model file
No high poly or low poly file for this product (the V04 delivery had none).

TECHNICAL
- glTF 2.0, every file checked with the Khronos glTF Validator: .glb, _Draco.glb, .gltf: 0 errors, 0 warnings
- real scale in metres: 60.7 cm wide, 51.8 cm high, 38.4 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 13 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- positions, normals, triangle order and zone assignment are byte for byte the V04 values; 8 vertices were duplicated
  (89,051 instead of 89,043) because the waistband is now split into outside and inside along the velcro flap slot
- Draco: KHR_draco_mesh_compression, quantisation position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)

ZONES (material names, unchanged since V04)
Z01_Waistband                  waistband outside incl. top edge, velcro field under the flap
Z02_Back_Waistband_Panel       back waistband panel (trapezoid, pointed at the bottom)
Z03_Front_Main_Panel           front panel left and right
Z04_Back_Main_Panel            back panel left and right
Z05_Side_Panel                 stripe on both sides of the side line, waistband to hem (no side seam in this short)
Z06_Side_Slit_Facing           facing at the round side slits
Z07_Velcro_Flap                velcro flap front
Z08_Velcro_Flap_Underside      underside of the flap (hook side, hidden when closed, not for design)
Z09_Reinforcement_Strip        vertical strip under the flap
Z11_Hem_Facing                 hem facing (inside, visible at the edge)
Z12_Inner_Waistband_Facing     waistband facing inside (not for design)
Z13_Crotch_Gusset              crotch gusset left and right
Z14_Outline                    outline binding, about 1 cm along the whole leg opening and around the slit, seam on its border
Not for design (hidden or inside): Z08_Velcro_Flap_Underside, Z12_Inner_Waistband_Facing.
Zones are not UV islands: the UV islands follow the pattern parts, the zones lie on top as materials.

UV MAP = PRODUCTION PATTERN (sheet group 5 "M 1")
Scale: one scale for every part, 1402.6 mm of the pattern per UV unit, 5.84 px per mm at 8192 px (1 cm = 58.4 px, scale bar in the template).
v = 0 is the top of the image (glTF / texture space), the same as the earlier templates. Left/right = seen by the person wearing the shorts.

production piece                         3D part (UV island)                          how
73  leg, right                           LEG RIGHT (front + back + side, one island)  below the waist line 89, sew line = cut line inset 12.7 mm;
                                                                                      leg opening and slit notch: no inset (binding wraps the raw edge)
73  strip above waist line 89            WAISTBAND RIGHT OUTSIDE (Z01)                from the front edge to where the back waistband panel starts
73  fly extension (front edge)           FLY STRIP (Z09 reinforcement strip)          the strip between the legs at the front
76  leg, left                            LEG LEFT                                     as 73
76  strip above waist line 90            WAISTBAND LEFT OUTSIDE (Z01)                 as 73
70  pentagon                             BACK WAISTBAND PANEL (Z02)                   sew line = cut line inset 12.7 mm
Hatched in the template (in the production cut, no 3D part there): the back end of the waistband strips (on the model the
back waistband panel covers this area), the small fly underlap of piece 76, and piece 68.

3D parts without a production piece (packed below the pattern, same scale, own flattening as in V04):
crotch gusset left and right (Z13), velcro flap (Z07), velcro flap underside (Z08), waistband inside left and right (Z12,
plus the thin Z01 edge above the flap slot), hem facings front/back left/right (Z11, Z06).

UV checks
- 16 islands, 0 flipped and 0 zero area UV triangles, nothing mirrored, all UVs inside 0 to 1
- no overlap; the parts cut from one production piece (leg, waistband outside, fly strip) touch along their split line
  (red dashed in the template), every other gap is at least 87 px at 4096
- template sew line vs. UV island edge of the GLB: mean 0.05 px, max 13.6 px at 8192 px (2.3 mm, at the fly corner)

KNOWN LIMITS
- The 3D model is larger than the size M production pattern: leg area 3D / pattern 1.73 (about 1.32 in length),
  waistband 1.0, back waistband panel 1.03. The design therefore appears scaled by about 1.3 on the legs of the model
  compared with a print at true size. The layout and proportions follow the production pattern exactly.
- The model's rise (crotch to waist) is longer than in the production cut, so the leg top is compressed slightly upward
  (stretch p95 about 1.35 on the legs).
- The model has a crotch gusset strip along each inner leg; the production cut sews the inner leg seams directly.

CHECKS (measured on the exported files)
glTF Validator, every file                 passed   0 errors, 0 warnings
Draco file loads (decoded with draco3d)    passed   yes, 166,878 triangles, max deviation 0.005 mm, UV 0.06 px at 8192
geometry vs V04 (positions per corner)     passed   max 0.0
normals vs V04                             passed   max 0.0
zone assignment vs V04                     passed   identical, 166,878 triangles
flipped / zero area UV triangles           passed   0 / 0
overlap in the atlas                       passed   0
orientation test (test texture rendered on the model in the viewer)   passed   text reads correctly, right piece on the right panel, TOP arrows up
em or en dash in text files                passed   0
