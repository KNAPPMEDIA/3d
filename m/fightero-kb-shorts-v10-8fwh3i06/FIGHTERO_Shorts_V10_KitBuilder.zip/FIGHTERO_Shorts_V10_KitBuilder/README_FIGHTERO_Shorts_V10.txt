FIGHTERO MMA Short, version V10
Delivery for the KitBuilder 3D configurator
Knapp Media, 27.11.2026
The regular MMA Short (long leg, side slit up to the hip), version V10.
This package replaces V09: same geometry, same zones and material names, NEW UV LAYOUT.
The UV template is now the Fightero production cut pattern (size L1, pattern sheet paths 61, 64, 60, 59):
a design laid out on the production cut pieces lands on the 3D model in the same place.

FILES
FIGHTERO_Shorts_V10.glb                         main file, 184,212 triangles, 4.3 MB
FIGHTERO_Shorts_V10_Draco.glb                   same geometry, Draco compressed (0.6 MB, for the web)
FIGHTERO_Shorts_V10.gltf                        same file as glTF (buffer embedded)
FIGHTERO_Shorts_V10_HighPoly_Draco.glb          736,848 triangles, one subdivision level, for close ups and renderings, Draco
FIGHTERO_Shorts_V10_LowPoly.glb                 46,053 triangles, if a very light model is needed (same UV layout and zones)
UV_Map/FIGHTERO_Shorts_V10_UV_Map.ai            Illustrator template, vector (PDF compatible .ai), 8192 pt artboard
UV_Map/FIGHTERO_Shorts_V10_UV_Map.pdf           same template as PDF
UV_Map/FIGHTERO_Shorts_V10_UV_Map.svg           same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Grid orientation,
                                Cut lines (production pattern), Sew lines = UV island edges, Extra parts without pattern piece, Labels;
                                cut lines, sew lines and extra part outlines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_Shorts_V10_UV_Map_8K.png        pixel template 8192 px
UV_Map/FIGHTERO_Shorts_V10_UV_Map_Preview.png   preview 1600 px
Images/FIGHTERO_Shorts_V10_Zones_Overview.png   the model from front, back, side, three quarter and bottom, every zone coloured, legend with the material names
Images/FIGHTERO_Shorts_V10_Preview_White.png    the model in white: front, side, back, three quarter
validator_FIGHTERO_Shorts_V10.txt               Khronos glTF Validator output for every model file

HOW TO DESIGN
- Design on the template exactly like on the production pattern sheet: the black lines are the cut lines of the
  production pattern (size L1), the red lines are the sew lines. Everything inside the red line is visible on the model.
- The strip between the red and the black line (12.7 mm seam allowance, 64 mm waist fold strip, 25 mm hem strip)
  is bleed: print it, it is not shown on the 3D model.
- One uniform scale for all pattern pieces: 1 mm on the pattern = 5.289 px at 8192 px (1 cm = 52.9 px).
- Pieces keep the position, size and upright orientation they have on the production pattern sheet, outside (print) face up, nothing mirrored.
- v = 0 is the top of the image (glTF convention, same as before). Create designs square (8192 px recommended).
- left/right = seen by the person wearing the shorts.

PIECES (pattern sheet path = UV island)
LEG LEFT   pattern path 64   front panel + back panel + side stripe + crotch gusset + outside waistband of the left leg
LEG RIGHT  pattern path 61   same for the right leg
           the leg piece is one piece on the pattern (no side seam): the side seam of the model lies on the slit line,
           the slit (paths 65 / 62) is the side slit of the model, the fold line (paths 80 / 79) is the top edge of the
           shorts, the hem line (paths 82 / 81) is the bottom edge (hem turned inside)
BACK WAISTBAND PANEL  pattern path 60  zone Z02; on the legs its position is marked ("back waistband panel sits here")
VELCRO FLAP           pattern path 59  folded on the notch line: upper half = outer flap Z07, lower half = underside Z08 (upside down on the sheet)
Parts without a pattern piece (inside parts and trims) are packed in the free space below, same texel density:
hem facings with side slit facings (Z11 / Z06, 4 parts), inner waistband facings (Z12, 2 parts), reinforcement strip (Z09).

TECHNICAL
- glTF 2.0, every model file checked with the Khronos glTF Validator: 0 errors, 0 warnings
- real scale in metres: 60.8 cm wide, 56.8 cm high, 38.4 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 12 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- Draco (KHR_draco_mesh_compression) quantisation: position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)

ZONES (material names, unchanged from V09)
Z01_Waistband                  waistband outside incl. top edge, velcro field under the flap
Z02_Back_Waistband_Panel       back waistband panel (pentagon, pointed at the bottom)
Z03_Front_Main_Panel           front panel left and right
Z04_Back_Main_Panel            back panel left and right
Z05_Side_Panel                 stripe on both sides of the side seam
Z06_Side_Slit_Facing           facing along the side slits
Z07_Velcro_Flap                velcro flap front
Z08_Velcro_Flap_Underside      underside of the flap (hook side, hidden when closed, not for design)
Z09_Reinforcement_Strip        vertical strip under the flap
Z11_Hem_Facing                 hem facing (inside, visible at the edge)
Z12_Inner_Waistband_Facing     waistband facing inside (not for design)
Z13_Crotch_Gusset              crotch gusset left and right

IMPORTANT NOTE ON SIZE
The 3D model is larger than the L1 production pattern: waist width matches (about 1 : 1), hem width is about 11 % larger,
but the outer leg length is about 41 % longer and the rise (waist to crotch) about 75 % deeper than on the pattern.
The UV layout follows the pattern exactly, so a design lands on the right piece and the right seam, but on the model it
appears stretched mainly in height in the leg and crotch area (area ratio model / pattern: legs 1.64 to 1.68,
back waistband panel 1.03, velcro flap 1.17). A true 1 : 1 print preview needs a 3D model built from the production pattern.

CHECKS (measured on the exported files)
Khronos glTF Validator
FIGHTERO_Shorts_V10.gltf                   errors 0, warnings 0
FIGHTERO_Shorts_V10.glb                    errors 0, warnings 0
FIGHTERO_Shorts_V10_Draco.glb              errors 0, warnings 0
FIGHTERO_Shorts_V10_HighPoly_Draco.glb     errors 0, warnings 0
FIGHTERO_Shorts_V10_LowPoly.glb            errors 0, warnings 0

Draco files load (decoded with the Google draco3d decoder)
FIGHTERO_Shorts_V10_Draco.glb              loads, 184,212 triangles, 12 materials, attributes POSITION NORMAL TEXCOORD_0
FIGHTERO_Shorts_V10_HighPoly_Draco.glb     loads, 736,848 triangles, 12 materials, attributes POSITION NORMAL TEXCOORD_0

UV and geometry (audit of the exported GLBs)
                                    main        LowPoly     HighPoly
UV islands                          11          11          11
flipped UV triangles                0           0           0
overlap in the atlas (px 2048)      0           0           0
mirrored parts                      0           0           0
UV island edge vs red sew line      mean 0.03 px, max 4.7 px at 8192 px (pattern pieces)

Geometry compared with V09
FIGHTERO_Shorts_V10.glb                    max difference position 0.0, normal 0.0, same triangles in the same order; only TEXCOORD_0 changed
FIGHTERO_Shorts_V10_HighPoly_Draco.glb     rebuilt (one subdivision level), positions equal to V09 HighPoly within Draco quantisation (p99 0.007 mm)
FIGHTERO_Shorts_V10_LowPoly.glb            rebuilt (collapse decimation, ratio 0.25, UV seams kept), 46,053 triangles (V09: 46,001)
