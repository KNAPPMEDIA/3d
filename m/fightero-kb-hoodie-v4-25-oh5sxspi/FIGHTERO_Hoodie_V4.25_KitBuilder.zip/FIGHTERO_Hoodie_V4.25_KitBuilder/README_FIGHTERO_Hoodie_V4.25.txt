FIGHTERO Zip Hoodie, version V4.25
Delivery for the KitBuilder 3D configurator
Knapp Media, 27.11.2026
The FIGHTERO zip hoodie (full zip front, two zip pockets, hood with centre strip and drawcords, rib waistband and cuffs), version V4.25.
Change to V4.24: new UV layout. The UV template is now the production cut pattern of the hoodie (Fightero pattern sheet, group 2, size L, "SPEEDO LYCRA"),
so a design made on the production cut pieces lands 1:1 on the 3D model. Geometry, topology, normals and zone materials are unchanged.

MODEL
FIGHTERO_Hoodie_V4.25.glb              main file, 228,868 triangles, 6.3 MB
FIGHTERO_Hoodie_V4.25.gltf             same file as glTF (buffer embedded)
FIGHTERO_Hoodie_V4.25_Draco.glb        same geometry, Draco compressed (657 KB, for the web)

Technical
- glTF 2.0, every file checked with the Khronos glTF Validator (gltf, glb, Draco.glb): 0 errors, 0 warnings, log: validator_FIGHTERO_Hoodie_V4.25.txt
- real scale in metres: 73.3 cm wide, 103.4 cm high, 32.5 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 8 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- Draco (KHR_draco_mesh_compression) quantisation: position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)
- cuffs and waistband are folded double layers of rib knit, seams are tapes on the surface, zippers are modelled (tape, teeth, puller)

ZONES (material names, unchanged since V4.24)
FIGHTERO_Hood_Centre   centre strip of the hood
FIGHTERO_Drawcord      both drawcords of the hood
FIGHTERO_Fabric        main fabric: front left and right, back, sleeves, hood sides, hood opening edge
FIGHTERO_Seam          seam tapes along the seams (neck and shoulders, hood, armholes, side seams, rib joins, pocket zipper frames)
FIGHTERO_Rib           rib knit: waistband and both cuffs
FIGHTERO_Metal         metal parts: zipper pullers and stops, drawcord eyelets (not for print design)
FIGHTERO_Zip_Tape      zipper tape: front zipper and both pocket zippers
FIGHTERO_Zip_Teeth     zipper teeth: front zipper and both pocket zippers

UV MAP = PRODUCTION PATTERN
- the 8 printed fabric parts are laid out exactly like the hoodie pieces on the production pattern sheet: same pieces, same relative positions,
  same upright orientation, outside (print) face up, nothing mirrored, ONE true scale for all pieces
- scale: 1 mm on the pattern = 2.637 px on an 8192 px design (1.319 px at 4096), the whole pattern group (3044 x 722 mm) spans u 0.01 to 0.99
- UV space 0 to 1, v = 0 at the top of the image (as in V4.24), create designs square (8192 px recommended)
- the edge of every UV island is the SEW line of its pattern piece (= edge of the visible fabric on the model); the CUT line lies 12.7 mm outside
  (seam allowance), print the design over the cut line as bleed
- the production pattern of the hoodie has cut lines only; the sew line is the cut line inset by 12.7 mm, the seam allowance measured on the
  other pattern pieces of the same sheet (12.70 mm on all seams). All hoodie edges are joined to another part (rib, zipper, strip, opening edge),
  so there is no turned up hem
- left/right = seen by the person wearing the hoodie

  pattern piece (path on the sheet)       UV island
  98  hood half, left on the sheet         HOOD RIGHT
  97  hood half, right on the sheet        HOOD LEFT
  96  strip 571.5 x 91.5 mm                HOOD CENTRE STRIP (face end on the left, neck end on the right)
  4   front, CF on its right edge          FRONT RIGHT (pocket line 6)
  7   front, CF on its left edge           FRONT LEFT (pocket line 9)
  2   back                                 BACK
  0   sleeve                               SLEEVE LEFT (front half of the sleeve on the left)
  10  sleeve, marked RIGHT                 SLEEVE RIGHT (front half of the sleeve on the right)

- parts without a printed pattern piece (waistband and cuff rib, hood opening edge, seam tapes, zippers, drawcords, eyelets) are packed below the
  pattern at the same true scale, numbered P1 to P35 with a list on the template; very small parts (seam ends, cord ends, eyelets) sit in one row
- 61 UV islands (unchanged), no overlaps, nothing mirrored (0 flipped UV triangles)

UV_Map/FIGHTERO_Hoodie_V4.25_UV_Map.ai           Illustrator template, vector (PDF compatible .ai), 8192 x 8192 pt
UV_Map/FIGHTERO_Hoodie_V4.25_UV_Map.pdf          same template as PDF
UV_Map/FIGHTERO_Hoodie_V4.25_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Grid orientation 100 mm,
                                                 Cut lines, Sew lines, Pattern marks, Labels, Scale bar;
                                                 cut lines and sew lines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_Hoodie_V4.25_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_Hoodie_V4.25_UV_Map_Preview.png  preview 1600 px
Template content: cut line black, sew line red, zone colours as in V4.24, English labels, pocket lines of the pattern (black) and the pocket
zipper opening of the 3D model (blue dashed), scale bars 1 cm and 10 cm with the mm to px value
Images/FIGHTERO_Hoodie_V4.25_Zones_Overview.png  front, back and side with every zone coloured and labelled, pocket zipper detail, legend with the material names
Images/FIGHTERO_Hoodie_V4.25_Preview_White.png   the model in white: front, side, back, three quarter

CHECKS (measured on the exported files of this package)
glTF validator, every file                    3 files, 0 errors, 0 warnings                                             passed
Draco file present and loads                  228,868 triangles decoded, max position deviation 0.008 mm                passed
geometry identical to V4.24                   max difference position 0.0, normal 0.0, indices identical, materials same   passed
UV islands                                    61                                                                        passed
flipped / zero area UV triangles              0 / 0                                                                     passed
overlap in the atlas (px at 4096)             0                                                                         passed
smallest gap between parts                    15 px at 4096                                                             passed
UV islands inside the 0 to 1 space            u 0.0100 to 0.9851, v 0.0143 to 0.4225                                    passed
island edge on the sew line (mean, 8K)        0.3 to 1.8 px per piece                                                   passed
orientation test (test texture, real renders) every piece on its panel, text reads correctly, TOP points up        passed
em or en dash characters in text files        0                                                                         passed

Notes (known differences between the 3D model and the production pattern)
- the hood centre strip of the model is wider than the pattern strip (84 to 106 mm against 66 mm between the sew lines, area ratio 1.24):
  a design on the strip is compressed across its width on the model
- the sleeve cap of the model is a set-in cap, taller than the flat cap of the pattern: near the shoulder a design is compressed
  (stretch p95 1.9 to 2.0 on the sleeves, 1.3 to 1.4 on all other pieces)
- the pocket zipper openings of the model sit about 7.4 cm nearer the centre front than the pocket lines of the pattern and are vertical;
  the template shows both
- small mesh flaps at seam ends (hood neck front, shoulder points, strip ends, hem corners) stick out over the sew line by up to 26 mm;
  the design under them comes from the seam allowance (bleed) area
- the fronts and the back of the model are 11 to 14 percent smaller in area than the pattern pieces (within the 15 percent tolerance)
