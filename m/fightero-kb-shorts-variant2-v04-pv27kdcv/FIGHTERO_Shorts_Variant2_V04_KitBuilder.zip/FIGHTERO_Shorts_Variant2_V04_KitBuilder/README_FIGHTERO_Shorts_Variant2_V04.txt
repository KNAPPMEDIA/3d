FIGHTERO MMA Short Variant2, version V04
Delivery for the KitBuilder 3D configurator
Knapp Media, 29.10.2026
Variant2 of the MMA Short: shorter leg (total height 51.8 cm), small round side slit (about 4 cm), no side seam,
outline binding along the leg opening and the slit (zone Z14), top part (waistband, flap, back panel) like Shorts V09.
First delivery of Variant2 in the KitBuilder format. Geometry, UVs and zones are exactly the approved Variant2 V04,
only the zone material names are now English (see ZONE NAMES).

FILES
FIGHTERO_Shorts_Variant2_V04.glb                    main file, 166,878 triangles, 3.9 MB
FIGHTERO_Shorts_Variant2_V04_Draco.glb              same geometry, Draco compressed (474 KB, for the web)
FIGHTERO_Shorts_Variant2_V04.gltf                   same file as glTF (buffer embedded)
UV_Map/FIGHTERO_Shorts_Variant2_V04_UV_Map.ai           Illustrator template, vector (PDF compatible .ai), cut lines, zone colours, labels
UV_Map/FIGHTERO_Shorts_Variant2_V04_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill,
                               Grid orientation, Cut lines, Labels; cut lines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_Shorts_Variant2_V04_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_Shorts_Variant2_V04_UV_Map_Preview.png  preview 1600 px
Images/FIGHTERO_Shorts_Variant2_V04_Zones_Overview.png  front, back and side with every zone coloured and labelled, legend with the material names
Images/FIGHTERO_Shorts_Variant2_V04_Preview_White.png   the model in white: front, side, back, three quarter
validator_FIGHTERO_Shorts_Variant2_V04.txt          Khronos glTF Validator output for every model file
No high poly or low poly file for this product (the approved V04 delivery had none).

TECHNICAL
- glTF 2.0, every file checked with the Khronos glTF Validator: .glb, _Draco.glb, .gltf: 0 errors, 0 warnings
- real scale in metres: 60.7 cm wide, 51.8 cm high, 38.4 cm deep, origin in the centre of the bounding box
  (the earlier V04 export used the master origin, 0.6 cm higher and 1.41 cm further to the front; the shape itself is unchanged)
- Y up, front faces +Z
- one mesh, 13 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- Draco: KHR_draco_mesh_compression, quantisation position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)
- waistband, hem and slit edges are folded with a facing on the inside (real fabric thickness at every edge), seams are shallow grooves,
  the seam along the outline binding is modelled as a groove (shape only, no own zone)

ZONES (material names)
Z01_Waistband                  waistband outside incl. top edge, velcro field under the flap
Z02_Back_Waistband_Panel       back waistband panel (trapezoid, pointed at the bottom)
Z03_Front_Main_Panel           front panel left and right
Z04_Back_Main_Panel            back panel left and right
Z05_Side_Panel                 stripe on both sides of the side line, waistband to hem (no side seam in this short)
Z06_Side_Slit_Facing           facing at the round side slits
Z07_Velcro_Flap                velcro flap front
Z08_Velcro_Flap_Underside      underside of the flap (hook side, hidden when closed, not for design)
Z09_Reinforcement_Strip        vertical strip under the flap
Z11_Hem_Facing                 hem facing (inside, visible at the edge)
Z12_Inner_Waistband_Facing     waistband facing inside (not for design)
Z13_Crotch_Gusset              crotch gusset left and right
Z14_Outline                    outline binding, about 1 cm along the whole leg opening and around the slit, seam on its border
Not for design (hidden or inside): Z08_Velcro_Flap_Underside, Z12_Inner_Waistband_Facing.
Zones are not UV islands: the UV islands follow the pattern parts, the zones lie on top as materials.

ZONE NAMES (English names since this delivery, the zone numbers and the order of the materials are unchanged)
material name                  previous name
Z01_Waistband                  Z01_Bund
Z02_Back_Waistband_Panel       Z02_Bundpanel_hinten
Z03_Front_Main_Panel           Z03_Hauptpanel_vorne
Z04_Back_Main_Panel            Z04_Hauptpanel_hinten
Z05_Side_Panel                 Z05_Seitenpanel
Z06_Side_Slit_Facing           Z06_Seitenschlitz_Einfassung
Z07_Velcro_Flap                Z07_Klettlasche
Z08_Velcro_Flap_Underside      Z08_Klettflaeche
Z09_Reinforcement_Strip        Z09_Verstaerkungsleiste
Z11_Hem_Facing                 Z11_Saum
Z12_Inner_Waistband_Facing     Z12_Innenfutter
Z13_Crotch_Gusset              Z13_Schrittzwickel
Z14_Outline                    Z14_Outline

UV MAP
- 14 parts like a sewing pattern, every part one UV island, cuts only on real seams
- no side seam: front and back panel of each leg are one island, the design runs from the front over the side to the back without a cut
- no overlaps, nothing mirrored, the same texel density on every part (about 3.2 px per mm at 4096)
- every part stands upright (up on the body = up in the UV)
- UV space 0 to 1, create designs square (4096 or 8192 px recommended)
- left/right = seen by the person wearing the shorts

CHECKS (measured on the exported files)
glTF Validator, every file                 passed   0 errors, 0 warnings
Draco file loads (decoded with draco3d)    passed   yes, 166,878 triangles, max deviation 0.006 mm (16 bit quantisation)
UV islands                                 passed   14 (one per pattern part, 0 cuts inside a part)
flipped UV triangles                       passed   0
zero area UV triangles                     passed   0
overlap in the atlas (px at 2048)          passed   0
smallest gap between parts (px at 4096)    passed   about 34
self intersections                         passed   0
angle distortion p95 (1.0 = none)          passed   1.204
geometry vs V04 export GLB (positions)     passed   max 0.00004 mm (float rounding of the metre conversion)
UVs vs V04 export GLB                      passed   max 0.0
zone assignment vs V04 export GLB          passed   identical, 166,878 of 166,878 triangles, every zone same corners and triangle count
em or en dash in text files                passed   0
