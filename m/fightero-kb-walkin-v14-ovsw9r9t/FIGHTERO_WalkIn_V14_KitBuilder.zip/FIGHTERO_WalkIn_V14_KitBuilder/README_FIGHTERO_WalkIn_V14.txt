FIGHTERO Walk In Jacket, version V14
Delivery for the KitBuilder 3D configurator
Knapp Media, 29.10.2026
The Walk In jacket (long sleeveless jacket with hood, front zipper and inner lining), current version V14.
Same geometry, UV layout and zones as the V14 delivered before; new in this package: English material names, zone images, this README.

FILES
FIGHTERO_WalkIn_V14.glb                    main file, 153,720 triangles, 5.0 MB
FIGHTERO_WalkIn_V14_Draco.glb              same geometry, Draco compressed (400 KB, for the web)
FIGHTERO_WalkIn_V14.gltf                   same file as glTF, buffer embedded (6.6 MB)
FIGHTERO_WalkIn_V14_HighPoly_Draco.glb     617,432 triangles, one subdivision level, for close ups and renderings, Draco (1.3 MB)
UV_Map/FIGHTERO_WalkIn_V14_UV_Map.ai           Illustrator template, vector (PDF compatible .ai): cut lines, zone colours, labels
UV_Map/FIGHTERO_WalkIn_V14_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Grid orientation, Cut lines, Labels;
                               cut lines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_WalkIn_V14_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_WalkIn_V14_UV_Map_Preview.png  preview 1600 px
Images/FIGHTERO_WalkIn_V14_Zones_Overview.png  front, side and back with every zone coloured and labelled, legend with the material names
Images/FIGHTERO_WalkIn_V14_Preview_White.png   the model in white: front, side, back, three quarter
validator_FIGHTERO_WalkIn_V14.txt          Khronos glTF Validator output for every glb and gltf in this package

TECHNICAL
- glTF 2.0, every file checked with the Khronos glTF Validator: 0 errors, 0 warnings
- real scale in metres: 44.4 cm wide, 103.9 cm high, 31.7 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 9 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- Draco (KHR_draco_mesh_compression): quantisation position 16 bit, UV 16 bit, normals 12 bit, compression level 7 (a Draco decoder is needed in the viewer)
- hood, armhole and front edges are bound with a binding (real fabric thickness at every edge), the jacket has a full inner lining, the hood a lining
- the zipper is modelled (teeth, slider, puller), it is its own zone

ZONES (material names)
Z01_Front_Panels     front panels left and right (outside)
Z02_Back_Panel       back panel (outside)
Z03_Hood_Outside     hood outside: left half, right half and centre strip
Z04_Hood_Lining      hood lining: left and right half
Z06_Bindings         bindings: hood edge and both armholes
Z07_Zip_Tape         zipper tape left and right
Z08_Zip_Metal        zipper metal: teeth, slider, puller (all teeth in one block in the UV map)
Z09_Inner_Lining     inner lining: front left, front right, back
Z10_Label            neck label inside the back (one small part, 3 UV pieces: both faces and the edge)
Z05 is not used (the zip placket zone of earlier versions no longer exists, the numbers of the other zones are kept).

ZONE NAMES (old to new, for an existing configurator setup)
material name (new)  previous name (V14 and earlier packages)
Z01_Front_Panels     Z01_Vorderteile
Z02_Back_Panel       Z02_Ruecken
Z03_Hood_Outside     Z03_Kapuze_aussen
Z04_Hood_Lining      Z04_Kapuze_innen
Z06_Bindings         Z06_Einfassungen
Z07_Zip_Tape         Z07_Reissverschlussband
Z08_Zip_Metal        Z08_Reissverschluss_Metall
Z09_Inner_Lining     Z09_Innenfutter
Z10_Label            Z10_Label
Zone order, zone numbers and the faces of every zone are unchanged, only the names are English now.

UV MAP
- 23 fabric parts like a sewing pattern, every part one UV island, cuts only on real seams; the zipper metal (3386 small islands: teeth, slider, puller) is packed in one block top right
- no overlaps, nothing mirrored, the same texel density on the fabric parts (about 1.9 px per mm at 4096, 17.6 to 20.2 px per cm)
- every part stands upright (up on the body = up in the UV)
- UV space 0 to 1, create designs square (4096 or 8192 px recommended)
- left/right = seen by the person wearing the jacket

CHECKS (measured on the exported files)
                                    main        HighPoly    
UV islands                          3409        3409        
flipped UV triangles                0           0           
zero area UV triangles              0           0           
overlap in the atlas (px 2048)      0           0           
smallest gap (px 4096)              10          10          
self intersections                  0           0           
angle distortion p95 (1.0 = none)   1.031       1.201       

Khronos glTF Validator
FIGHTERO_WalkIn_V14.gltf                      0 errors, 0 warnings
FIGHTERO_WalkIn_V14.glb                       0 errors, 0 warnings
FIGHTERO_WalkIn_V14_Draco.glb                 0 errors, 0 warnings
FIGHTERO_WalkIn_V14_HighPoly_Draco.glb        0 errors, 0 warnings

Draco: FIGHTERO_WalkIn_V14_Draco.glb decodes and loads (153,720 triangles, 9 materials), largest position difference to the main file after decoding 0.0099 mm (16 bit quantisation)
Geometry and UVs compared with the previous V14 main file: positions max difference 0.0, UVs max difference 0.0, normals max difference 0.0, triangle list identical: yes (108,376 vertices, 153,720 triangles)
HighPoly compared with the previous V14 HighPoly: positions max difference 0.0, UVs max difference 0.0
