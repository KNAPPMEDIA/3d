FIGHTERO MMA Short, version V09
Delivery for the KitBuilder 3D configurator
Knapp Media, 29.10.2026
The regular MMA Short (long leg, side slit up to the hip, side seam), current version V09.
This package replaces the V09 package of 15.10.2026: same geometry, same UVs, same zones, the zone material names are now English (see ZONE NAMES).

FILES
FIGHTERO_Shorts_V09.glb                         main file, 184,212 triangles, 4.3 MB
FIGHTERO_Shorts_V09_Draco.glb                   same geometry, Draco compressed (528 KB, for the web)
FIGHTERO_Shorts_V09.gltf                        same file as glTF (buffer embedded)
FIGHTERO_Shorts_V09_HighPoly_Draco.glb          736,842 triangles, one subdivision level, for close ups and renderings, Draco
FIGHTERO_Shorts_V09_LowPoly.glb                 46,001 triangles, if a very light model is needed (same UV layout and zones)
UV_Map/FIGHTERO_Shorts_V09_UV_Map.ai            Illustrator template, vector (PDF compatible .ai), cut lines, zone colours, labels
UV_Map/FIGHTERO_Shorts_V09_UV_Map.svg           same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Grid orientation, Cut lines, Labels;
                                cut lines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_Shorts_V09_UV_Map_8K.png        pixel template 8192 px
UV_Map/FIGHTERO_Shorts_V09_UV_Map_Preview.png   preview 1600 px
Images/FIGHTERO_Shorts_V09_Zones_Overview.png   the model from front, back, side, top and bottom, every zone coloured and labelled, legend with the material names
Images/FIGHTERO_Shorts_V09_Preview_White.png    the model in white: front, side, back, three quarter
validator_FIGHTERO_Shorts_V09.txt               Khronos glTF Validator output for every model file

TECHNICAL
- glTF 2.0, every model file checked with the Khronos glTF Validator: 0 errors, 0 warnings
- real scale in metres: 60.8 cm wide, 56.8 cm high, 38.4 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 12 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- Draco (KHR_draco_mesh_compression) quantisation: position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)
- waistband, hem and slit edges are folded with a facing on the inside (real fabric thickness at every edge), seams are shallow grooves with stitch dents

ZONES (material names)
Z01_Waistband                  waistband outside incl. top edge, velcro field under the flap
Z02_Back_Waistband_Panel       back waistband panel (trapezoid, pointed at the bottom)
Z03_Front_Main_Panel           front panel left and right
Z04_Back_Main_Panel            back panel left and right
Z05_Side_Panel                 stripe on both sides of the side seam
Z06_Side_Slit_Facing           facing along the side slits
Z07_Velcro_Flap                velcro flap front
Z08_Velcro_Flap_Underside      underside of the flap (hook side, hidden when closed, not for design)
Z09_Reinforcement_Strip        vertical strip under the flap
Z11_Hem_Facing                 hem facing (inside, visible at the edge)
Z12_Inner_Waistband_Facing     waistband facing inside (not for design)
Z13_Crotch_Gusset              crotch gusset left and right

ZONE NAMES (old to new, to map an existing configurator setup; zone numbers and material order unchanged)
material name (now)            previous name (V09 delivery of 15.10.2026)
Z01_Waistband                  Z01_Bund
Z02_Back_Waistband_Panel       Z02_Bundpanel_hinten
Z03_Front_Main_Panel           Z03_Hauptpanel_vorne
Z04_Back_Main_Panel            Z04_Hauptpanel_hinten
Z05_Side_Panel                 Z05_Seitenpanel
Z06_Side_Slit_Facing           Z06_Seitenschlitz_Einfassung
Z07_Velcro_Flap                Z07_Klettlasche
Z08_Velcro_Flap_Underside      Z08_Klettflaeche
Z09_Reinforcement_Strip        Z09_Verstaerkungsleiste
Z11_Hem_Facing                 Z11_Saum
Z12_Inner_Waistband_Facing     Z12_Innenfutter
Z13_Crotch_Gusset              Z13_Schrittzwickel

UV MAP
- 16 parts like a sewing pattern, every part one UV island, cuts only on real seams
- no overlaps, nothing mirrored, the same texel density on every part (about 3.1 px per mm at 4096)
- every part stands upright (up on the body = up in the UV)
- UV space 0 to 1, create designs square (4096 or 8192 px recommended)
- left/right = seen by the person wearing the shorts
- note: at the right end of the waistband two very small faces (under 1 cm on the model) have a long, thin UV spike;
  it shows as a thin line next to WAISTBAND RIGHT in the template, it does not overlap any other part and has no visible effect on the model

CHECKS (measured on the exported files)
Khronos glTF Validator
FIGHTERO_Shorts_V09.gltf                   errors 0, warnings 0
FIGHTERO_Shorts_V09.glb                    errors 0, warnings 0
FIGHTERO_Shorts_V09_Draco.glb              errors 0, warnings 0
FIGHTERO_Shorts_V09_HighPoly_Draco.glb     errors 0, warnings 0
FIGHTERO_Shorts_V09_LowPoly.glb            errors 0, warnings 0

Draco files load (decoded with the Google draco3d decoder)
FIGHTERO_Shorts_V09_Draco.glb              loads, 184,212 triangles, 12 materials, attributes POSITION NORMAL TEXCOORD_0
FIGHTERO_Shorts_V09_HighPoly_Draco.glb     loads, 736,842 triangles, 12 materials, attributes POSITION NORMAL TEXCOORD_0

UV and geometry (audit of the exported GLBs)
                                    main        LowPoly     HighPoly    
UV islands                          16          16          16          
flipped UV triangles                0           0           0           
zero area UV triangles              0           0           0           
overlap in the atlas (px 2048)      0           0           0           
smallest gap (px 4096)              34          34          34          
self intersections                  0           0           0           
angle distortion p95 (1.0 = none)   1.182       1.646       2.174       
cuts inside a part                  0           1           0           
The one cut inside a part of the LowPoly is a single 8 mm edge on the side slit facing (Z06) where the two UV corners
are 0.004 apart (result of the decimation, invisible in use); main file and HighPoly have none.

Geometry and UVs compared with the V09 delivery of 15.10.2026
FIGHTERO_Shorts_V09.glb                    max difference position 0.0, UV 0.0, normal 0.0 (binary geometry buffer byte identical)
FIGHTERO_Shorts_V09_Draco.glb              max difference position 0.0, UV 0.0 (binary geometry buffer byte identical)
FIGHTERO_Shorts_V09_HighPoly_Draco.glb     max difference position 0.0, UV 0.0 (binary geometry buffer byte identical)
FIGHTERO_Shorts_V09_LowPoly.glb            max difference position 0.0, UV 0.0, normal 0.0 (binary geometry buffer byte identical)
FIGHTERO_Shorts_V09.gltf                   max difference position 0.0, UV 0.0, normal 0.0 (binary geometry buffer byte identical)
