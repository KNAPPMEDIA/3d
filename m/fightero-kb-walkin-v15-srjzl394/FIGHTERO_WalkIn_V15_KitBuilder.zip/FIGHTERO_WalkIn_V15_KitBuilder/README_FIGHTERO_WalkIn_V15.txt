FIGHTERO Walk In Jacket, version V15
Delivery for the KitBuilder 3D configurator
Knapp Media, 27.11.2026
The Walk In jacket (long sleeveless jacket with hood, front zipper and inner lining), version V15.
New in V15: the UV layout of the outer fabric now IS the Fightero production cut pattern (pattern sheet "01-SCHNITTMUSTER-alle-teile", group 1, size L).
A design made on the production cut pattern lands 1:1 on the 3D model. Geometry, triangle list, normals and zones are identical to V14, only the UVs changed.

FILES
FIGHTERO_WalkIn_V15.glb                    main file, 153,720 triangles, 5.0 MB
FIGHTERO_WalkIn_V15_Draco.glb              same geometry, Draco compressed (413 KB, for the web)
FIGHTERO_WalkIn_V15.gltf                   same file as glTF, buffer embedded (6.6 MB)
FIGHTERO_WalkIn_V15_HighPoly_Draco.glb     617,432 triangles, one subdivision level, for close ups and renderings, Draco (1.6 MB)
UV_Map/FIGHTERO_WalkIn_V15_UV_Map.ai           Illustrator template, vector (PDF compatible .ai): cut lines, sew lines, zone colours, labels, 1 cm scale bar
UV_Map/FIGHTERO_WalkIn_V15_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Grid orientation, Cut lines, Sew lines, Labels;
                               cut lines and sew lines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_WalkIn_V15_UV_Map.pdf          same template as PDF
UV_Map/FIGHTERO_WalkIn_V15_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_WalkIn_V15_UV_Map_Preview.png  preview 1600 px
Images/FIGHTERO_WalkIn_V15_Zones_Overview.png  front, side and back with every zone coloured and labelled, legend with the material names (geometry and zones unchanged since V14)
Images/FIGHTERO_WalkIn_V15_Preview_White.png   the model in white: front, side, back, three quarter
validator_FIGHTERO_WalkIn_V15.txt          Khronos glTF Validator output for every glb and gltf in this package

TECHNICAL
- glTF 2.0, every file checked with the Khronos glTF Validator: 0 errors, 0 warnings
- real scale in metres: 44.4 cm wide, 103.9 cm high, 31.7 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 9 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- Draco (KHR_draco_mesh_compression): quantisation position 16 bit, UV 16 bit, normals 12 bit, compression level 7 (a Draco decoder is needed in the viewer)
- hood, armhole and front edges are bound with a binding (real fabric thickness at every edge), the jacket has a full inner lining, the hood a lining
- the zipper is modelled (teeth, slider, puller), it is its own zone

ZONES (material names, unchanged since V14)
Z01_Front_Panels     front panels left and right (outside)
Z02_Back_Panel       back panel (outside)
Z03_Hood_Outside     hood outside: left half, right half and centre strip
Z04_Hood_Lining      hood lining: left and right half
Z06_Bindings         bindings: hood edge and both armholes
Z07_Zip_Tape         zipper tape left and right
Z08_Zip_Metal        zipper metal: teeth, slider, puller (all teeth in one block in the UV map)
Z09_Inner_Lining     inner lining: front left, front right, back
Z10_Label            neck label inside the back (one small part, 3 UV pieces: both faces and the edge)
Z05 is not used (the zip placket zone of earlier versions no longer exists, the numbers of the other zones are kept).
Older packages (V14 and earlier, German names): Z01_Vorderteile, Z02_Ruecken, Z03_Kapuze_aussen, Z04_Kapuze_innen, Z06_Einfassungen,
Z07_Reissverschlussband, Z08_Reissverschluss_Metall, Z09_Innenfutter, Z10_Label.

UV MAP = PRODUCTION CUT PATTERN
- the six outer fabric parts are placed exactly like group 1 of the Fightero pattern sheet, at one uniform real scale:
  1 mm = 5.449 px at 8192 (2.724 px at 4096), 1 cm = 54.5 px at 8192; v = 0 is the top of the image
  pattern piece (sheet path cut / sew)    3D part            zone
  HOOD RIGHT   (19, cut only)             hood half right    Z03_Hood_Outside
  HOOD LEFT    (17, cut only)             hood half left     Z03_Hood_Outside
  HOOD CENTRE STRIP (21, cut only)        hood centre strip  Z03_Hood_Outside (top of the strip = forehead, bottom = back neck)
  FRONT RIGHT  (87 / 88)                  front panel right  Z01_Front_Panels
  FRONT LEFT   (12 / 13)                  front panel left   Z01_Front_Panels
  BACK         (14 / 16)                  back panel         Z02_Back_Panel
- black = CUT line of the pattern, red = SEW line. The edge of each UV island lies on the sew line: everything inside the red line is visible on the model,
  the band between red and black is seam allowance (12.7 mm) or hem (25.4 mm, the bottom edge is the folded hem). Let the design bleed to the black line.
- the hood pieces and the strip have no sew line on the sheet: their sew line is the cut line inset by the measured seam allowance of 12.7 mm
- every pattern piece keeps its upright orientation from the sheet, outside (print face) up, nothing mirrored
- left/right = seen by the person wearing the jacket (on the sheet, as when you look at the jacket: RIGHT pieces left on the sheet)
- parts without a production pattern piece (linings, hood lining, bindings, zipper tapes, zipper metal, label) are packed in the free space at 52.3 % of the pattern scale and labelled
- UV space 0 to 1, create designs square (4096 or 8192 px recommended)

CHECKS (measured on the exported files)
                                    main        HighPoly
flipped UV triangles                0           0
zero area UV triangles              0           0
overlap in the atlas (px 2048)      0           0
smallest gap, fabric parts       20 (px 4096)  10 (px 2048)
UV island edge vs sew line (8K px)  mean 0.06, max 7.6 (chord of a 16 mm mesh edge on the back neck curve)

pattern piece   stretch p95   area 3D / pattern
HOOD RIGHT      1.64          0.92
HOOD LEFT       1.59          0.91
HOOD STRIP      1.27          0.81  (the 3D strip is shorter than the pattern strip)
FRONT RIGHT     1.46          0.98
FRONT LEFT      1.49          0.98
BACK            1.42          0.98
stretch = max(s1, 1/s2) of the 3D to pattern mapping (1.0 = none); the stretch sits mainly at the shoulders, where the 3D shoulder seam lies further forward than on the pattern.

Geometry compared with V14: positions max difference 0.0, normals max difference 0.0, triangle list identical (108,376 vertices, 153,720 triangles), only TEXCOORD_0 changed
Draco: FIGHTERO_WalkIn_V15_Draco.glb decodes and loads (153,720 triangles, 9 materials), largest position difference to the main file after decoding 0.0099 mm (16 bit quantisation)
HighPoly: one Catmull Clark level of the master, UVs interpolated linearly (so the design sits exactly as on the main file)
