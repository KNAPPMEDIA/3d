FIGHTERO Zip Hoodie, version V4.24
Delivery for the KitBuilder 3D configurator
Knapp Media, 29.10.2026
The FIGHTERO zip hoodie (full zip front, two zip pockets, hood with centre strip and drawcords, rib waistband and cuffs), current version V4.24.
Change to the previous package of V4.24: the zone material names are now English (see ZONE NAMES). Geometry, UVs and zone assignment are unchanged.

MODEL
FIGHTERO_Hoodie_V4.24.glb              main file, 228,868 triangles, 6.3 MB
FIGHTERO_Hoodie_V4.24.gltf             same file as glTF (buffer embedded)
FIGHTERO_Hoodie_V4.24_Draco.glb        same geometry, Draco compressed (663 KB, for the web)

Technical
- glTF 2.0, every file checked with the Khronos glTF Validator (gltf, glb, Draco.glb): 0 errors, 0 warnings, log: validator_FIGHTERO_Hoodie_V4.24.txt
- real scale in metres: 73.3 cm wide, 103.4 cm high, 32.5 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 8 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0
- Draco (KHR_draco_mesh_compression) quantisation: position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)
- cuffs and waistband are folded double layers of rib knit, seams are tapes on the surface, zippers are modelled (tape, teeth, puller)

ZONES (material names)
FIGHTERO_Hood_Centre   centre strip of the hood (outside and inside)
FIGHTERO_Drawcord      both drawcords of the hood
FIGHTERO_Fabric        main fabric: front left and right, back, sleeves, hood sides, hood opening edge
FIGHTERO_Seam          seam tapes along the seams (neck and shoulders, hood, armholes, side seams, rib joins, pocket zipper frames)
FIGHTERO_Rib           rib knit: waistband and both cuffs
FIGHTERO_Metal         metal parts: zipper pullers and stops, drawcord eyelets (not for print design)
FIGHTERO_Zip_Tape      zipper tape: front zipper and both pocket zippers
FIGHTERO_Zip_Teeth     zipper teeth: front zipper and both pocket zippers

ZONE NAMES (English names since this package, for mapping an existing configurator setup)
material name (new)    previous name (V4.24 and older)
FIGHTERO_Hood_Centre   FIGHTERO_Kapuzenmitte
FIGHTERO_Drawcord      FIGHTERO_Kordel
FIGHTERO_Fabric        FIGHTERO_Stoff
FIGHTERO_Seam          FIGHTERO_Naht
FIGHTERO_Rib           FIGHTERO_Rippe
FIGHTERO_Metal         FIGHTERO_Metall
FIGHTERO_Zip_Tape      FIGHTERO_Zipband
FIGHTERO_Zip_Teeth     FIGHTERO_Zaehne

UV MAP
- 61 parts like a sewing pattern, every part one UV island: 8 fabric parts (front left and right, back, sleeves, hood sides, hood opening edge), 1 hood centre strip, 5 rib parts, 36 seam tapes, 6 drawcord parts, 3 zipper tapes, 3 zipper teeth strips, 5 metal parts
- no overlaps, nothing mirrored (0 flipped UV triangles)
- texel density: about 2.4 px per mm at 4096 on all fabric, rib, hood centre and drawcord parts (24.4 px per cm, median per material); seam tapes, metal and zipper parts 1.2 to 2.8 px per mm
- body parts stand upright (up on the body = up in the UV); long strips (zippers, seam tapes, hood centre strip, drawcords, waistband) lie along their length
- UV space 0 to 1, create designs square (4096 or 8192 px recommended)
- left/right = seen by the person wearing the hoodie (labels on the UV map and in the images)

UV_Map/FIGHTERO_Hoodie_V4.24_UV_Map.ai           Illustrator template, vector (PDF compatible .ai), cut lines, zone colours, labels
UV_Map/FIGHTERO_Hoodie_V4.24_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Grid orientation, Cut lines, Labels;
                                                 cut lines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_Hoodie_V4.24_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_Hoodie_V4.24_UV_Map_Preview.png  preview 1600 px
Images/FIGHTERO_Hoodie_V4.24_Zones_Overview.png  front, back and side with every zone coloured and labelled, pocket zipper detail, legend with the material names
                                                 (same colours as the UV map)
Images/FIGHTERO_Hoodie_V4.24_Preview_White.png   the model in white: front, side, back, three quarter

CHECKS (measured on the exported files of this package)
glTF validator, every file               3 files, 0 errors, 0 warnings                                             passed
Draco file present and loads             228,868 triangles decoded, max position deviation 0.008 mm                passed
UV islands                               61                                                                        passed
flipped UV triangles                     0                                                                         passed
zero area UV triangles                   0                                                                         passed
overlap in the atlas (px at 2048)        0                                                                         passed
smallest gap between parts               54 px at 4096                                                             passed
self intersections                       0                                                                         passed
angle distortion p95 (1.0 = none)        1.539                                                                     passed
geometry identical to V4.24 release      max difference position 0.0, UV 0.0, normal 0.0, indices identical: yes   passed
UV islands inside the 0 to 1 space       u 0.0081 to 0.9944, v 0.0082 to 0.9788                                    passed
em or en dash characters in text files   0                                                                         passed

Notes
- 143 edges are cut in the UV without splitting their part (slits): drawcords 116 (lengthwise seam of the cord), cuffs 23, one sleeve 4. They do not cause overlaps; a print running across such a slit can show a small jump.
- at the two points where the underarm seam meets the cuff seam a few small faces are stretched in the UV by more than 50 percent; visible only if a print runs exactly over that spot.
