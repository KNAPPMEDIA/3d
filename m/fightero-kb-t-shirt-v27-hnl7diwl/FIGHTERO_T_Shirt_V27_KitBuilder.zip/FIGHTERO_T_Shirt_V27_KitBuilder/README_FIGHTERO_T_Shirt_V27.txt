FIGHTERO T SHIRT, version V27
Delivery for the KitBuilder 3D configurator
Knapp Media, 27.11.2026
The regular FIGHTERO T Shirt (crew neck rib collar, set in short sleeves, turned up hem and sleeve ends), current version V27.
V27 = V26 geometry with a NEW UV LAYOUT: the UV template is now the real FIGHTERO production cut pattern (T-shirt pieces of
01-SCHNITTMUSTER, group 3). A design made on the production cut pattern lands 1:1 on the 3D model.
Geometry, topology, zones and material names are unchanged against V26 (vertex position max diff 0). Only the UVs changed.

FILES
FIGHTERO_T_Shirt_V27.glb                        main file, 163,740 triangles, 3.8 MB
FIGHTERO_T_Shirt_V27_Draco.glb                  same geometry, Draco compressed (459 KB, for the web)
FIGHTERO_T_Shirt_V27.gltf                       same file as glTF (buffer embedded)
FIGHTERO_T_Shirt_V27_HighPoly_Draco.glb         654,960 triangles, one subdivision level, for close ups and renderings, Draco (1.3 MB)
FIGHTERO_T_Shirt_V27_LowPoly.glb                50,222 triangles, if a very light model is needed (same UV layout and zones, 1.3 MB)
UV_Map/FIGHTERO_T_Shirt_V27_UV_Map.ai           Illustrator template, vector (PDF compatible .ai), 8192 x 8192 pt artboard
UV_Map/FIGHTERO_T_Shirt_V27_UV_Map.pdf          same template as PDF
UV_Map/FIGHTERO_T_Shirt_V27_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Seam thread islands,
                               Grid orientation, Cut lines, Sew lines, Fold and hem lines, UV island edges, Labels;
                               cut lines, sew lines of the sleeves and all UV island edges are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_T_Shirt_V27_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_T_Shirt_V27_UV_Map_Preview.png  preview 1600 px
Images/FIGHTERO_T_Shirt_V27_Zones_Overview.png  front, back, side and a sleeve end close up, every zone coloured and labelled (geometry and zones as V26)
Images/FIGHTERO_T_Shirt_V27_Preview_White.png   the model in white: front, side, back, three quarter (geometry as V26)
Images/FIGHTERO_T_Shirt_V27_UV_Orientation_Test.png  a test texture (piece names, TOP arrows, 2 cm grid) on the V27 model, real renders
validator_FIGHTERO_T_Shirt_V27.txt              Khronos glTF Validator output for every model file
README_FIGHTERO_T_Shirt_V27.txt                 this file

TECHNICAL
- glTF 2.0, every model file checked with the Khronos glTF Validator: 0 errors, 0 warnings
- real scale in metres: 60.4 cm wide, 69.9 cm high, 24.0 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 6 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0 (one UV set)
- Draco (KHR_draco_mesh_compression) quantisation: position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)
- hem and sleeve ends are turned up with real fabric thickness and a topstitch, the collar is a rolled rib band, seams carry overlock beads
  and topstitches as separate thread geometry (zone Z06_Seam_Threads, so the thread colour can be set on its own)

ZONES (material names, unchanged)
Z01_Front_Panel      front panel, one piece, with the turned up hem and its topstitch
Z02_Back_Panel       back panel, one piece, with the turned up hem and its topstitch
Z03_Sleeve_Left      left sleeve (wearer view, +X), with the turned up sleeve end and its topstitch
Z04_Sleeve_Right     right sleeve (wearer view, -X), with the turned up sleeve end and its topstitch
Z05_Collar           collar, rib band all around: outside, rolled top edge, inside
Z06_Seam_Threads     seam threads: overlock beads on the seams and the single topstitches (thread colour)

UV MAP = PRODUCTION PATTERN
- the pieces sit exactly as on the FIGHTERO pattern sheet (T-shirt group): collar strip top left, the two sleeves below it,
  back and front side by side; ONE uniform scale for all pieces, real proportions, fitted into the 0 to 1 square with a 2 % margin
- scale: 1 UV unit = 1828.8 mm, 4.479 px per mm at 8192 px (1 cm = 44.79 px), 2.240 px per mm at 4096 px
- glTF / texture space: v = 0 is the TOP of the image (same as before), every piece stands upright as on the pattern sheet
- seen from the outside (print side), nothing mirrored
- black line = production CUT line, red line = production SEW line = edge of the visible fabric = edge of the UV island
- the seam allowance between cut and sew line (12.7 mm) and the hem allowance are bleed: print the design across them
- hem: dashed red = fold line of the hem (= bottom edge of the shirt on the model). The UV island continues below the fold
  by the turned up part that is visible inside the shirt (body 10.8 mm, sleeves 14.9 mm), like a printed and folded fabric
- sleeves: the sleeve sew line bottom is the sleeve hem fold
- collar: the rib strip is folded lengthwise; the LOWER half of the strip (below the dashed fold line) is the visible outside of the
  collar, upright, the upper half is turned to the inside. The collar seam (join) is at centre back, at both short ends of the strip.
  The production strip has no sew line; the sew line is the cut line inset by the 12.7 mm seam allowance (dashed red)
- pairing: top sleeve on the sheet = Z03_Sleeve_Left, bottom sleeve = Z04_Sleeve_Right (both production sleeves are identical)
- Z06_Seam_Threads: 1032 small islands, packed below the pattern pieces (free space, labelled), they are not part of the print pattern
- 1037 UV islands in total, no overlaps between pieces, nothing mirrored, no flipped or zero area UV triangles
- create designs square (4096 or 8192 px recommended)

FIT OF THE 3D PANELS ON THE PATTERN (measured)
piece                 pattern piece                                   area 3D / pattern   stretch p95
Z01_Front_Panel       front (path 28 cut / 29 sew, deep neck)         0.910              1.261
Z02_Back_Panel        back (path 26 cut / 27 sew, shallow neck)       0.934              1.219
Z03_Sleeve_Left       sleeve, top one on the sheet (85 / 86)          1.235              1.520
Z04_Sleeve_Right      sleeve, bottom one on the sheet (57 / 58)       1.235              1.531
Z05_Collar            collar rib strip (56, sew line = cut inset by 12.7 mm) 0.905              1.112
  (stretch p95 = 95th percentile of the larger of stretch and compression, area weighted, 1.0 = none)
  Note: the 3D sleeves are about 23 % larger in area than the production sleeve (sleeve cap seam 570 mm on the model, 478 mm on the pattern),
  so on the sleeves a design is compressed to fit the model; front and back are 7 to 9 % smaller than the pattern.

CHECKS (measured on the exported files)
Khronos glTF Validator: passed
  FIGHTERO_T_Shirt_V27.glb errors 0 warnings 0 infos 6
  FIGHTERO_T_Shirt_V27_Draco.glb errors 0 warnings 0 infos 13
  FIGHTERO_T_Shirt_V27.gltf errors 0 warnings 0 infos 6
  FIGHTERO_T_Shirt_V27_HighPoly_Draco.glb errors 0 warnings 0 infos 13
  FIGHTERO_T_Shirt_V27_LowPoly.glb errors 0 warnings 0 infos 6

UV island edge against the sew line of the template (8192 px): Z01_Front_Panel mean 0.08 max 0.10 px, Z02_Back_Panel mean 0.08 max 0.10 px, Z03_Sleeve_Left mean 0.05 max 0.29 px, Z04_Sleeve_Right mean 0.06 max 0.29 px, Z05_Collar mean 0.05 max 0.10 px
  (front and back: on the 2.5 mm side piece between the end of the production sew line and the hem fold line, max 4.5 px)
angle distortion p95 (fabric zones): main 1.566, LowPoly 1.667, HighPoly 1.608
Geometry against V26: positions max diff 0, normals max diff 0, triangles and zone assignment identical (main, glTF, LowPoly, Draco and
  HighPoly Draco decoded)
HighPoly and LowPoly carry the same UV layout: their V26 UVs were mapped through the V26 to V27 layout of the main mesh (same geometry as V26).
