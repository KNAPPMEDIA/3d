FIGHTERO T SHIRT, version V26
Delivery for the KitBuilder 3D configurator
Knapp Media, 29.10.2026
The regular FIGHTERO T Shirt (crew neck rib collar, set in short sleeves, turned up hem and sleeve ends), current version V26.
This package is the V26 geometry with English material names (see ZONE NAMES); geometry, UVs and zones are unchanged.

FILES
FIGHTERO_T_Shirt_V26.glb                        main file, 163,740 triangles, 3.8 MB
FIGHTERO_T_Shirt_V26_Draco.glb                  same geometry, Draco compressed (364 KB, for the web)
FIGHTERO_T_Shirt_V26.gltf                       same file as glTF (buffer embedded)
FIGHTERO_T_Shirt_V26_HighPoly_Draco.glb         654,960 triangles, one subdivision level, for close ups and renderings, Draco (1.2 MB)
FIGHTERO_T_Shirt_V26_LowPoly.glb                50,222 triangles, if a very light model is needed (same UV layout and zones, 1.3 MB)
UV_Map/FIGHTERO_T_Shirt_V26_UV_Map.ai           Illustrator template, vector (PDF compatible .ai), cut lines, zone colours, labels
UV_Map/FIGHTERO_T_Shirt_V26_UV_Map.svg          same template as SVG, 8192 px artboard, layers: Background white, Zones fill, Grid orientation, Cut lines, Labels;
                               cut lines are closed paths (usable as clipping masks)
UV_Map/FIGHTERO_T_Shirt_V26_UV_Map_8K.png       pixel template 8192 px
UV_Map/FIGHTERO_T_Shirt_V26_UV_Map_Preview.png  preview 1600 px
Images/FIGHTERO_T_Shirt_V26_Zones_Overview.png  front, back, side and a sleeve end close up, every zone coloured and labelled, legend with the material names
Images/FIGHTERO_T_Shirt_V26_Preview_White.png   the model in white: front, side, back, three quarter
validator_FIGHTERO_T_Shirt_V26.txt              Khronos glTF Validator output for every model file
README_FIGHTERO_T_Shirt_V26.txt                 this file

TECHNICAL
- glTF 2.0, every model file checked with the Khronos glTF Validator: 0 errors, 0 warnings
- real scale in metres: 60.4 cm wide, 69.9 cm high, 24.0 cm deep, origin in the centre of the bounding box
- Y up, front faces +Z
- one mesh, 6 materials = the colour zones of the configurator (all white, not metallic, roughness 0.85, double sided)
- no textures embedded, the design comes from the configurator
- attributes: POSITION, NORMAL (smooth), TEXCOORD_0 (one UV set)
- Draco (KHR_draco_mesh_compression) quantisation: position 16 bit, UV 16 bit, normals 12 bit (a Draco decoder is needed in the viewer)
- hem and sleeve ends are turned up with real fabric thickness and a topstitch, the collar is a rolled rib band, seams carry overlock beads
  and topstitches as separate thread geometry (zone Z06_Seam_Threads, so the thread colour can be set on its own)

ZONES (material names)
Z01_Front_Panel      front panel, one piece, with the turned up hem and its topstitch
Z02_Back_Panel       back panel, one piece, with the turned up hem and its topstitch
Z03_Sleeve_Left      left sleeve (wearer view, +X), with the turned up sleeve end and its topstitch
Z04_Sleeve_Right     right sleeve (wearer view, -X), with the turned up sleeve end and its topstitch
Z05_Collar           collar, rib band all around: outside, rolled top edge, inside
Z06_Seam_Threads     seam threads: overlock beads on the seams and the single topstitches (thread colour)

ZONE NAMES (new English name, previous name in the earlier deliveries, for mapping an existing configurator setup)
material name (new)  previous name        UV islands
Z01_Front_Panel      Z01_Vorderteil       1
Z02_Back_Panel       Z02_Rueckenteil      1
Z03_Sleeve_Left      Z03_Aermel_links     1
Z04_Sleeve_Right     Z04_Aermel_rechts    1
Z05_Collar           Z05_Kragen           1
Z06_Seam_Threads     Z06_Naehte           1032

UV MAP
- 1037 UV islands: 5 fabric parts like a sewing pattern (front, back, sleeve left, sleeve right, collar), cuts only on real seams,
  plus 1032 small islands for the seam thread pieces (overlock beads and topstitch dents, zone Z06_Seam_Threads)
- no overlaps, nothing mirrored, the same texel density on every part (about 3.5 px per mm at 4096)
- every part stands upright (up on the body = up in the UV)
- UV space 0 to 1, create designs square (4096 or 8192 px recommended)
- left/right = seen by the person wearing the shirt (left sleeve = +X)

CHECKS (measured on the exported files)
Khronos glTF Validator: passed
  FIGHTERO_T_Shirt_V26.glb errors 0 warnings 0 infos 6
  FIGHTERO_T_Shirt_V26_Draco.glb errors 0 warnings 0 infos 13
  FIGHTERO_T_Shirt_V26.gltf errors 0 warnings 0 infos 6
  FIGHTERO_T_Shirt_V26_HighPoly_Draco.glb errors 0 warnings 0 infos 13
  FIGHTERO_T_Shirt_V26_LowPoly.glb errors 0 warnings 0 infos 6

UV and mesh audit:
                              main        LowPoly     HighPoly    
UV islands                    1037        1037        1037        
flipped UV triangles          0           0           0           
zero area UV triangles        0           0           0           
overlap in the atlas (px)     0           0           0           
smallest gap (px 4096)        2           2           2           
self intersections            0           0           0           
angle distortion p95          1.129       2.654       1.563       
  (angle distortion p95: 1.0 = none; overlap measured in the 2048 px atlas)

Draco files decode and load (Draco decoder, gltf-transform): FIGHTERO_T_Shirt_V26_Draco.glb 88,231 vertices / 163,740 triangles / 6 zones, FIGHTERO_T_Shirt_V26_HighPoly_Draco.glb 339,165 vertices / 654,960 triangles / 6 zones: passed

Geometry and UVs against the previous V26 delivery (German material names): passed, identical
  FIGHTERO_T_Shirt_V26.glb                   positions max diff 0.0, UV max diff 0.0, triangles and zone assignment identical: yes
  FIGHTERO_T_Shirt_V26.gltf                  positions max diff 0.0, UV max diff 0.0, triangles and zone assignment identical: yes
  FIGHTERO_T_Shirt_V26_LowPoly.glb           positions max diff 0.0, UV max diff 0.0, triangles and zone assignment identical: yes
  FIGHTERO_T_Shirt_V26_Draco.glb             positions max diff 0, UV max diff 0, triangles and zone assignment identical: yes
  FIGHTERO_T_Shirt_V26_HighPoly_Draco.glb    positions max diff 0, UV max diff 0, triangles and zone assignment identical: yes
